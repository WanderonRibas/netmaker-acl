package models

// moved from controllers need work
//func TestUpdateNetwork(t *testing.T) {
//	initialize()
//	createNet()
//	network := getNet()
//	t.Run("NetID", func(t *testing.T) {
//		var networkupdate models.Network
//		networkupdate.NetID = "wirecat"
//		Range, local, err := network.Update(&networkupdate)
//		assert.NotNil(t, err)
//		assert.Equal(t, "NetID is not editable", err.Error())
//		t.Log(err, Range, local)
//	})
//}
