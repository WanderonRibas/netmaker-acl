package models

type CreateGwReq struct {
	IngressRequest
	RelayRequest
	InetNodeReq
}

type DeleteGw struct {
}
