package logger

type entry struct {
	Time  string
	Count int
}
