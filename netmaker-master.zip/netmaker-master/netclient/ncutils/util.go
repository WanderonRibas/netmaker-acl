package ncutils

// CheckInInterval - the interval for check-in time in units/minute
const CheckInInterval = 1
