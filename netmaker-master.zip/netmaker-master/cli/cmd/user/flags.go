package user

var (
	username     string
	password     string
	platformID   string
	admin        bool
	networkRoles map[string]string
	groups       []string
)
