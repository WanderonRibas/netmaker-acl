package dns

var (
	dnsName     string
	address     string
	address6    string
	networkName string
	dnsType     string
)
