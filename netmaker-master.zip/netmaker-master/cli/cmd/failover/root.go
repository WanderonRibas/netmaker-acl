package failover

import (
	"os"

	"github.com/spf13/cobra"
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "failover",
	Short: "Enable/Disable failover for a node associated with a network",
	Long:  `Enable/Disable failover for a node associated with a network`,
}

// GetRoot returns the root subcommand
func GetRoot() *cobra.Command {
	return rootCmd
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}
