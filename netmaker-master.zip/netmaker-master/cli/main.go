package main

import (
	"github.com/gravitl/netmaker/cli/cmd"
)

func main() {
	cmd.Execute()
}
